import { useState } from "react";

export const Header = () => {
    const [loginButton, setLoginButton] = useState("Login")
    return <div className = "header">
                {/* <div className="logo-container"> */}
                    <img className="logo" src="https://static.vecteezy.com/system/resources/thumbnails/007/500/121/small_2x/food-delivery-icon-clip-art-logo-simple-illustration-free-vector.jpg" />
                {/* </div> */}
                <div className="nav-items">
                    <ul>
                        <li><a href="http://localhost:1234/">Home</a></li>
                        <li>About</li>
                        <li>Contact us</li>
                        <li>Cart</li>
                        <button className="login-button" onClick={() => loginButton === "Login" ? setLoginButton("Logout") : setLoginButton("Login")}>
                            {loginButton}
                        </button>
                    </ul>
                </div>
            </div>
};

export default Header;