const RestaurantCard = (props) => {
    const {name, cuisines, avgRating, cloudinaryImageId} = props?.data.info;
    const {deliveryTime} = props?.data.info.sla;
    return <div className="restaurant-card">
        <img className="restaurant-logo"src={"https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_264,h_288,c_fill/"+cloudinaryImageId}/>
        <h3>{name}</h3>
        <h4>{cuisines.join(", ")}</h4>
        <h5>{avgRating} stars</h5>
        <h5>{deliveryTime} minutes</h5>
    </div>
}

export default RestaurantCard;