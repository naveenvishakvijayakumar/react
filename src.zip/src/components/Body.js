import { useState, useEffect } from "react";
import RestaurantCard from "./RestaurantCard";
import Shimmer from "./Shimmer";
import restaurantsData from "../mockData/restaurantsData.json"

const Body = () => {
    const [listOfRestaurants, setListOfRestaurants] = useState([]);
    const [filteredRestaurants, setFilteredRestaurants] = useState([]);
    const [searchText, setSearchText] = useState("");
    const fetchData = async () => {
        const data = await fetch("https://www.swiggy.com/dapi/restaurants/list/v5?lat=11.0168445&lng=76.9558321&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING/");
        const json = await data.json();
        return json?.data?.cards[1]?.card?.card?.gridElements?.infoWithStyle?.restaurants;
    }
    useEffect(() => {
        fetchData().then(data => {
            setListOfRestaurants(data);
            setFilteredRestaurants(data);
        })
    }, []);
    return !listOfRestaurants.length ? <div className="app-body"><Shimmer/></div> : (<div className="app-body">
                <div className="filter">
                    <div className="search">
                        <input type="text" className="search-box" value={searchText} onChange={(e) => {
                            setSearchText(e.target.value);
                            const filteredRestaurants = listOfRestaurants.filter(data => {
                                return data.info.name.toLowerCase().includes(e.target.value.toLocaleLowerCase());
                            });
                            setFilteredRestaurants(filteredRestaurants);
                        }}></input>
                        <button className="search-button" onClick={() => {
                            const filteredRestaurants = listOfRestaurants.filter(data => {
                                return data.info.name.toLowerCase().includes(searchText.toLocaleLowerCase());
                            });
                            setFilteredRestaurants(filteredRestaurants);
                        }}>
                            Search
                        </button>
                    </div>
                    <button className="top-rated" onClick={() => setFilteredRestaurants(filteredRestaurants.filter(data => data.info.avgRating > 4.3))}>
                        Top Rated Restaurants
                    </button>
                </div>
                <div className="restaurant-container">
                    {
                        filteredRestaurants.map(data => {
                            return <RestaurantCard key = {data?.info.id} data = {data}/>
                        })
                    }
                </div>
            </div>)
}

export default Body;