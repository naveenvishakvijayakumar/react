import React from "react";
import ReactDOM from "react-dom/client"
import restaurantsData from "./mockData/restaurantsData.json"
import Header from "./components/Header";
import Body from "./components/Body";

const root = ReactDOM.createRoot(document.getElementById("root"));
const App = () => {
    return <div className="app">
        <Header/>
        <Body data = {restaurantsData}/>  {/* props arewrapped inside an object and passed as argument */}
    </div>
};

root.render(<App />);